const express = require('express');
const { get } = require('http');
const res = express();
const port = "3000";
const axios = require('axios');
var exp = require('express-handlebars');

url = "http://dummy.restapiexample.com/api/v1/employees";

res.use(express.static('Public'))

res.engine('handlebars', exp({defaultLayout : 'table'}));
res.set('view engine', 'handlebars');

res.get("/",(req,res)=>{
        axios.get(url).then((response) =>{
            result = response.data.data;
            console.log(JSON.stringify(response.data.data));
        }).catch((error) => {
        })
        res.render('Home', {data: result});
    })

res.listen(port,()=>{
    console.log("Server Running on Port 3000");
})