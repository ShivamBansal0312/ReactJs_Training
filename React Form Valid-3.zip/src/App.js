import React from 'react';
import './App.css';
import FormValidation from './Form';



function App() {
  return (
    <div className="App">
       <FormValidation/> 
    </div>
  );
}

export default App;
