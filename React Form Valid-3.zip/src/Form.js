import React from 'react';
import Button from 'react-bootstrap/Button';
import './App.css';
//import Drop from './Shor';
// import Drop from './Shor';

class FormValidation extends React.Component {
    constructor() {
    super();
    this.state = {
      input: {},
      errors: {},
    };
     
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleChange(event) {
    let input = this.state.input;
    input[event.target.name] = event.target.value;
    this.setState({
      input
    });
  }
     
  handleSubmit(event) {
    event.preventDefault();
  
    if(this.validate()){
        console.log(this.state);
  
        let input = {};
        input["assname"] = "";
        input["assId"] = "";
        input["prjId"] = "";
        input["comment"] = "";
        input["upload"] = "";
        input["shore"] = "";
        this.setState({input:input});
  
        alert('Form is submited');
    }
  }
  validate(){
      let input = this.state.input;
      let errors = {};
      let isValid = true;
  
      if (!input["assname"]) {
        isValid = false;
        errors["assname"] = "Please enter your name.";
        
      }
  
      if (!input["prjId"]) {
        isValid = false;
        errors["prjId"] = "Please enter Project Id";
      }
  
      if (typeof input["prjId"] !== "undefined") {
          
        var pattern = new RegExp(/^[a-z0-9]+$/i);
        if (!pattern.test(input["prjId"])) {
          isValid = false;
          errors["prjId"] = "Please enter valid Project Id";
        }
      }
  
      if (!input["assId"]) {
        isValid = false;
        errors["assId"] = "Please enter associate id";
      }
  
      if (typeof input["assId"] !== "undefined") {
          
        var pattern1 = new RegExp(/^[0-9\b]+$/);
        if (!pattern1.test(input["assId"])) {
          isValid = false;
          errors["assId"] = "Please enter only number.";
        }else if(input["assId"].length !== 6){
          isValid = false;
          errors["assId"] = "Invalid Id";
        }
      }
  
      if (!input["comment"]) {
        isValid = false;
        errors["comment"] = "Please enter your comment.";
      }

      if(!input["upload"]){
          isValid = false;
          errors["upload"] = "Please Upload the file"
      }
      if(!input["skills"]){
        isValid = false;
        errors["skills"] = "Please Upload the file"
    }
      
  
      this.setState({
        errors: errors
      });
  
      return isValid;
  }
  render() {
    var myStyle3 ={
        borderColor : '#000000',
        border: 1.5 ,
        borderStyle : 'solid',
        padding : 3,
        borderRadius : 4,
        size: 20,
        marginTop: 0
    };
    var myStyle = {
      height: 40,
      width: 475,
      border:1.5,
      borderColor:'#000000',
      borderStyle:'solid',
      borderRadius: 5,
      marginTop:10,
      marginBottom: 30,
      flex:1
  }
    return (       
        <form onSubmit={this.handleSubmit}>
        
        <h2> React Form Validation<small style={{color:"red"}}>*</small></h2>
          <div class="form-group">
            <input 
              type="text" 
              name="assname" 
              value={this.state.input.assname}
              onChange={this.handleChange}
              class="form-control" 
              placeholder="Associate Name" 
              id="assname"/>
  
              <div style={{color:"red"}}>
                  <small>{this.state.errors.assname}
                  </small></div>
          </div>
 
          <div class="form-group">
            <input 
              type="text" 
              name="assId" 
              value={this.state.input.assId}
              onChange={this.handleChange}
              class="form-control" 
              placeholder="Associate Id" 
              id="assId" />
  
              <div style={{color:"red"}}><small>{this.state.errors.assId}</small></div>
          </div>

          <div class="form-group">
            <input 
              type="text" 
              name="prjId" 
              value={this.state.input.prjId}
              onChange={this.handleChange}
              class="form-control" 
              placeholder="Project ID" 
              id="prjId" />
  
              <div style={{color:"red"}}><small>{this.state.errors.prjId}</small></div>
          </div>
           <div class="form-group">
          
        </div> 

          <div class="form-group" id="skill">
            <section>
            <input type="Checkbox" value="html"/> HTML5,CSS3,JS   
            </section>
            <section>
            <input type="Checkbox" value="ang"/> Angular 8 
            </section>
            <section>
            <input type="Checkbox" value="exp"/> Express JS 
            </section>
            <section>
            <input type="Checkbox" value="sass"/> SASS
            </section>
            <section>
            <input type="Checkbox" value="react"/> React JS
            </section>
            <section>
            <input type="Checkbox" value="node"/> Node JS 
            </section>
            <section>
            <input type="Checkbox" value="es"/> ES5,ES6,ES7....
            </section>
            <section>
            <input type="Checkbox" value="veu"/> Veu JS 
            </section>
            <section>
            <input type="Checkbox" value="db"/> Mondo DB 
            </section>
            <section>
            <input type="Checkbox" value="boot"/> BootStrap4
            </section>
            <section>
            <input type="Checkbox" value="ts"/> TypeScript
            </section>
          </div>

          <div class="form-group">
              <h4 >Upload Profile</h4>
              <input name="upload" 
              style={myStyle3} 
              type="file" 
              value={this.state.input.upload}
              onChange={this.handleChange} />

              <div style={{color:"red"}}><small>{this.state.errors.upload}</small></div>
          </div>


          <div class="form-group" id="comments">            
            <textarea 
              name="comment"
              value={this.state.input.comment} 
              onChange={this.handleChange}
              placeholder="Comments"
              class="form-control"
              id="ta" />
  
              <div style={{color:"red"}}><small>{this.state.errors.comment}</small></div>
          </div>


          <div class="form-group">
             <Button type='submit' variant="primary">Submit</Button>
             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
             <Button type='reset' variant="danger">Reset</Button>
          </div>
          {/* <Drop/> */}
          


          
        </form>
        
    );
  }
}
export default FormValidation;






