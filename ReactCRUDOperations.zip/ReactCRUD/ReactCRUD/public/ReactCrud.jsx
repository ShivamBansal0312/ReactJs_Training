
var JobAll = React.createClass({   
  
    getInitialState: function () {  
      return { jobid: '' ,jobtitle: '',jobdate:'',jobrole:'',jobrespon:'',jobcomp:'',jobexp:'',jobsalary:'',
      jobposition:'',joblocation:'',jobskill:'',jobdegree:'',jobinfo:'',jobemploy:'',jobindust:'',jobsearch:'',jobdescp:'',id:'',Buttontxt:'Save', data1: []};  
    },  
     handleChange: function(e) {  
          this.setState({[e.target.name]: e.target.value});  
      },  
    
    componentDidMount() {  
     
      $.ajax({  
         url: "api/getdata",  
         type: "GET",  
         dataType: 'json',  
         ContentType: 'application/json',  
         success: function(data) {           
           this.setState({data1: data});   
             
         }.bind(this),  
         error: function(jqXHR) {  
           console.log(jqXHR);  
               
         }.bind(this)  
      });  
    },  
      
  DeleteData(id){  
    var studentDelete = {  
          'id': id  
             };        
      $.ajax({  
        url: "/api/Removedata/",  
        dataType: 'json',  
        type: 'POST',  
        data: studentDelete,  
        success: function(data) {  
          alert(data.data);  
           this.componentDidMount();  
    
        }.bind(this),  
        error: function(xhr, status, err) {  
           alert(err);   
               
              
        }.bind(this),  
        });  
      },  
     
      EditData(item){           
     this.setState({jobid: item.jobid,jobtitle:item.jobtitle,jobrole:item.jobrole,jobdate:item.jobdate,jobrespon: item.jobrespon,jobcomp: item.jobcomp,jobexp: item.jobexp,jobsalary: item.jobsalary,
      jobposition: item.jobposition,joblocation: item.joblocation,jobskill: item.jobskill,jobdegree: item.jobdegree,jobinfo: item.jobinfo,
      jobemploy: item.jobemploy,jobindust: item.jobindust,jobsearch: item.jobsearch,jobdescp: item.jobdescp,id:item._id,Buttontxt:'Update'});  
       },  
    
     handleClick: function() {  
     
     var Url="";  
     if(this.state.Buttontxt=="Save"){  
        Url="/api/savedata";  
         }  
        else{  
        Url="/api/Updatedata";  
        }  
        var studentdata = {  
          'jobid': this.state.jobid,  
          'jobtitle':this.state.jobtitle,  
          'jobdate':this.state.jobdate,  
          'jobrole':this.state.jobrole, 
          'jobrespon':this.state.jobrespon,  
          'jobcomp':this.state.jobcomp, 
          'jobexp':this.state.jobexp,
          'jobsalary':this.state.jobsalary,
          'jobposition':this.state.jobposition,  
          'joblocation':this.state.joblocation,
          'jobskill':this.state.jobskill,
          'jobdegree':this.state.jobdegree,
          'jobinfo':this.state.jobinfo,
          'jobemploy':this.state.jobemploy,
          'jobindust':this.state.jobindust,
          'jobsearch':this.state.jobsearch,
          'jobdescp':this.state.jobdescp,
          'id':this.state.id,  
            
      }  
      $.ajax({  
        url: Url,  
        dataType: 'json',  
        type: 'POST',  
        data: studentdata,  
        success: function(data) {         
            alert(data.data);         
            this.setState(this.getInitialState());  
            this.componentDidMount();  
             
        }.bind(this),  
        error: function(xhr, status, err) {  
           alert(err);       
        }.bind(this)  
      });  
    },  
    
    render: function() {  
      return (   
        <div  className="container"  style={{marginTop:'30px'}}>  
         <p className="text-center" style={{fontSize:'25px',padding:'5px', background:'lightblue'}}><b> Admin | Employer Post Jobs </b></p>  
    <form style={{marginTop:'30px'}}>  
      <div className="col-sm-12 col-md-12"  >   
    <table className="table-bordered">  
       <tbody>  
      <tr>  
        <td style={{padding:'15px'}}><b>Job Id</b></td>  
        <td>  
           <input className="form-control" type="text" value={this.state.jobid}    name="jobid" onChange={ this.handleChange } />  
            <input type="hidden" value={this.state.id}    name="id"  />  
        </td>  
      </tr>  
    
      <tr>  
        <td style={{padding:'15px'}}><b>Job Title</b></td>  
        <td>  
        <input type="text" className="form-control" value={this.state.jobtitle}  name="jobtitle" onChange={ this.handleChange } />  
        </td>  
      </tr>  
    
      <tr>  
        <td style={{padding:'15px'}}><b>Job Posted Date</b></td>  
        <td>  
          <input type="date"  className="form-control" value={this.state.jobdate}  name="jobdate" onChange={ this.handleChange } />  
        </td>  
      </tr>  
    
    
      <tr>  
        <td style={{padding:'15px'}}><b>Role</b></td>  
        <td>  
          <input type="text"  className="form-control" value={this.state.jobrole}  name="jobrole" onChange={ this.handleChange } />  
        </td>  
      </tr>  

      <tr>  
        <td style={{padding:'15px'}}><b>Responsibility</b></td>  
        <td>  
        <input type="text" className="form-control" value={this.state.jobrespon}  name="jobrespon" onChange={ this.handleChange } />  
        </td>  
      </tr> 

      <tr>  
        <td style={{padding:'15px'}}><b>Company Name</b></td>  
        <td>  
        <input type="text" className="form-control" value={this.state.jobcomp}  name="jobcomp" onChange={ this.handleChange } />  
        </td>  
      </tr> 

      <tr>  
        <td style={{padding:'15px'}}><b>Experience</b></td>  
        <td>  
        <input type="text" className="form-control" value={this.state.jobexp}  name="jobexp" onChange={ this.handleChange } />  
        </td>  
      </tr> 

      <tr>  
        <td style={{padding:'15px'}}><b>Salary Range</b></td>  
        <td>  
        <input type="text" className="form-control" value={this.state.jobsalary}  name="jobsalary" onChange={ this.handleChange } />  
        </td>  
      </tr> 

      <tr>  
        <td style={{padding:'15px'}}><b>No of Positions</b></td>  
        <td>  
        <input type="text" className="form-control" value={this.state.jobposition}  name="jobposition" onChange={ this.handleChange } />  
        </td>  
      </tr>

      <tr>  
        <td style={{padding:'15px'}}><b>Location</b></td>  
        <td>  
        <input type="text" className="form-control" value={this.state.joblocation}  name="joblocation" onChange={ this.handleChange } />  
        </td>  
      </tr>

      <tr>  
        <td style={{padding:'15px'}}><b>Skills and Qualifications</b></td>  
        <td>  
        <input type="text" className="form-control" value={this.state.jobskill}  name="jobskill" onChange={ this.handleChange } />  
        </td>  
      </tr>

      <tr>  
        <td style={{padding:'15px'}}><b>Degree</b></td>  
        <td>  
        <input type="text" className="form-control" value={this.state.jobdegree}  name="jobdegree" onChange={ this.handleChange } />  
        </td>  
      </tr>

      <tr>  
        <td style={{padding:'15px'}}><b>Company Info</b></td>  
        <td>  
        <input type="text" className="form-control" value={this.state.jobinfo}  name="jobinfo" onChange={ this.handleChange } />  
        </td>  
      </tr>

      <tr>  
        <td style={{padding:'15px'}}><b>Employment Type</b></td>  
        <td>  
        <input type="text" className="form-control" value={this.state.jobemploy}  name="jobemploy" onChange={ this.handleChange } />  
        </td>  
      </tr>

      <tr>  
        <td style={{padding:'15px'}}><b>Industry Type</b></td>  
        <td>  
        <input type="text" className="form-control" value={this.state.jobindust}  name="jobindust" onChange={ this.handleChange } />  
        </td>  
      </tr>

      <tr>  
        <td style={{padding:'15px'}}><b>Search keyword</b></td>  
        <td>  
        <input type="text" className="form-control" value={this.state.jobsearch}  name="jobsearch" onChange={ this.handleChange } />  
        </td>  
      </tr>

      <tr>  
        <td style={{padding:'15px'}}><b>Job Description</b></td>  
        <td>  
        <input type="text" className="form-control" value={this.state.jobdescp}  name="jobdescp" onChange={ this.handleChange } />  
        </td>  
      </tr>
    
      <tr>  
        <td></td>  
        <td style={{padding:'15px'}}>  
          <input className="btn btn-primary" type="button" value={this.state.Buttontxt} onClick={this.handleClick} />  
        </td>  
      </tr>  
    
   </tbody>  
      </table>  
  </div>  
     
    
  <div className="col-sm-12 col-md-12 "  style={{paddingTop:'30px',paddingBottom:'30px'}}>  
     
   <table className="table-bordered"><tbody>  
     <tr>
       <th style={{padding:'20px'}}><b>S.No</b></th>
       <th style={{padding:'20px'}}><b>JOB ID</b></th>
       <th style={{padding:'20px'}}><b>JOB TITLE</b></th>
       <th style={{padding:'20px'}}><b>JOB POSTED DATE</b></th>
       <th style={{padding:'20px'}}><b>ROLE</b></th>
       <th style={{padding:'20px'}}><b>RESPONSIBILITY</b></th>
       <th style={{padding:'20px'}}><b>COMPANY NAME</b></th>
       <th style={{padding:'20px'}}><b>EXPERIENCE</b></th>
       <th style={{padding:'20px'}}><b>SALARY RANGE</b></th>
       <th style={{padding:'20px'}}><b>NO OF POSITIONS</b></th>
       <th style={{padding:'20px'}}><b>LOCATION</b></th>
       <th style={{padding:'20px'}}><b>SKILLS & QUALIFICAATION</b></th>
       <th style={{padding:'20px'}}><b>DEGREE</b></th>
       <th style={{padding:'20px'}}><b>COMPANY INFO</b></th>
       <th style={{padding:'20px'}}><b>EMPLOYMENT TYPE</b></th>
       <th style={{padding:'20px'}}><b>INDUSTRY TYPE</b></th>
       <th style={{padding:'20px'}}><b>SEARCH KEYWORD</b></th>
       <th style={{padding:'20px'}}><b>JOB DESCRIPTION</b></th>
       <th style={{padding:'20px'}}><b>Edit</b></th>
       <th style={{padding:'20px'}}><b>Delete</b></th>
      </tr>  
      {this.state.data1.map((item, index) => (  
          <tr key={index}>  
             <td style={{padding:'10px'}}>{index+1}</td>   
            <td style={{padding:'10px'}}>{item.jobid}</td>                        
            <td style={{padding:'10px'}}>{item.jobtitle}</td>  
            <td style={{padding:'10px'}}>{item.jobdate}</td>  
            <td style={{padding:'10px'}}>{item.jobrole}</td>
            <td style={{padding:'10px'}}>{item.jobrespon}</td>  
            <td style={{padding:'10px'}}>{item.jobcomp}</td>
            <td style={{padding:'10px'}}>{item.jobexp}</td>
            <td style={{padding:'10px'}}>{item.jobsalary}</td>
            <td style={{padding:'10px'}}>{item.jobposition}</td>
            <td style={{padding:'10px'}}>{item.joblocation}</td>
            <td style={{padding:'10px'}}>{item.jobskill}</td>
            <td style={{padding:'10px'}}>{item.jobdegree}</td>
            <td style={{padding:'10px'}}>{item.jobinfo}</td>
            <td style={{padding:'10px'}}>{item.jobemploy}</td>
            <td style={{padding:'10px'}}>{item.jobindust}</td>
            <td style={{padding:'10px'}}>{item.jobsearch}</td>
            <td style={{padding:'10px'}}>{item.jobdescp}</td>
             <td style={{padding:'10px'}}>   
              
             <button type="button" className="btn btn-success" onClick={(e) => {this.EditData(item)}}>Edit</button>      
            </td>   
            <td style={{padding:'10px'}}>   
               <button type="button" className="btn btn-info" onClick={(e) => {this.DeleteData(item._id)}}>Delete</button>  
            </td>   
          </tr>  
      ))}  
      </tbody>  
      </table>  
       </div>  
  </form>          
        </div>  
      );  
    }  
  });  
    
  ReactDOM.render(<JobAll  />, document.getElementById('root'))