var express = require("express");  
var path = require("path");  
var mongo = require("mongoose");   
var bodyParser = require('body-parser');   
var morgan = require("morgan");  
var db = require("./config.js");  
  
var app = express();  
var port = process.env.port || 7777;  
var srcpath  =path.join(__dirname,'/public') ;  
app.use(express.static('public'));  
app.use(bodyParser.json({limit:'10mb'}));    
app.use(bodyParser.urlencoded({extended:true, limit:'10mb'}));  
  
  
var mongoose = require('mongoose');  
var Schema = mongoose.Schema;  
var jobSchema = new Schema({      
    jobid: { type: String   },       
    jobtitle: { type: String   },     
    jobdate: { type: Date },       
    jobrole: { type: String },
    jobrespon: { type: String },      
    jobcomp: { type: String },
    jobexp: { type: String },
    jobsalary: { type: String },
    jobposition: { type: String },
    joblocation: { type: String },
    jobskill: { type: String },
    jobdegree: { type: String },
    jobinfo: { type: String },
    jobemploy: { type: String },
    jobindust: { type: String },
    jobsearch: { type: String },
    jobdescp: { type: String },
},{ versionKey: false });  
   
  
var model = mongoose.model('job', jobSchema, 'job');  
  
//api for get data from database  
app.get("/api/getdata",function(req,res){   
 model.find({},function(err,data){  
            if(err){  
                res.send(err);  
            }  
            else{             
                res.send(data);  
                }  
        });  
})  
  
  
//api for Delete data from database  
app.post("/api/Removedata",function(req,res){   
 model.remove({ _id: req.body.id }, function(err) {  
            if(err){  
                res.send(err);  
            }  
            else{    
                   res.send({data:"Record has been Deleted..!!"});             
               }  
        });  
})  
  
  
//api for Update data from database  
app.post("/api/Updatedata",function(req,res){   
 model.findByIdAndUpdate(req.body.id, { jobid:  req.body.jobid, jobtitle: req.body.jobtitle, jobdate: req.body.jobdate, jobrole:req.body.jobrole, jobrespon: req.body.jobrespon, jobcomp: req.body.jobcomp, jobexp: req.body.jobexp,
     jobsalary: req.body.jobsalary, jobposition: req.body.jobposition, joblocation: req.body.joblocation, jobskill: req.body.jobskill, jobdegree: req.body.jobdegree, jobinfo: req.body.jobinfo, jobemploy: req.body.jobemploy,
      jobindust: req.body.jobindust, jobsearch: req.body.jobsearch, jobdescp: req.body.jobdescp },   
function(err) {  
 if (err) {  
 res.send(err);  
 return;  
 }  
 res.send({data:"Record has been Updated..!!"});  
 });  
})    
  
  
//api for Insert data from database  
app.post("/api/savedata",function(req,res){   
       
    var mod = new model(req.body);  
        mod.save(function(err,data){  
            if(err){  
                res.send(err);                
            }  
            else{        
                 res.send({data:"Record has been Inserted..!!"});  
            }  
        });  
})  
      
// call by default index.html page  
app.get("*",function(req,res){   
    res.sendFile(srcpath +'/index.html');  
})  
  
//server stat on given port  
app.listen(port,function(){   
    console.log("server start on port"+ port);  
}) 